import { pgTable, text, serial, integer, boolean, jsonb, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema from the original file
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Business search related schemas
export const businessSchema = z.object({
  place_id: z.string(),
  name: z.string(),
  formatted_address: z.string().optional(),
  vicinity: z.string().optional(),
  rating: z.number().optional(),
  user_ratings_total: z.number().optional(),
  opening_hours: z.object({
    open_now: z.boolean().optional()
  }).optional(),
  photos: z.array(z.object({
    photo_reference: z.string(),
    height: z.number(),
    width: z.number(),
    html_attributions: z.array(z.string())
  })).optional(),
  price_level: z.number().optional(),
  geometry: z.object({
    location: z.object({
      lat: z.number(),
      lng: z.number()
    })
  }),
  types: z.array(z.string()).optional()
});

export type Business = z.infer<typeof businessSchema>;

export const searchParamsSchema = z.object({
  district: z.string(),
  businessType: z.string(),
  radius: z.number().optional(),
  openNow: z.boolean().optional(),
  minRating: z.number().optional(),
  priceLevel: z.array(z.number()).optional(),
  pageToken: z.string().optional(),
  sortBy: z.enum(["relevance", "rating", "reviews", "distance"]).optional()
});

export type SearchParams = z.infer<typeof searchParamsSchema>;

export const searchResultSchema = z.object({
  results: z.array(businessSchema),
  next_page_token: z.string().optional(),
  total: z.number().optional()
});

export type SearchResult = z.infer<typeof searchResultSchema>;

// Istanbul districts with coordinates
export const districtsSchema = z.array(z.object({
  id: z.string(),
  name: z.string(),
  location: z.object({
    lat: z.number(),
    lng: z.number()
  })
}));

export type District = z.infer<typeof districtsSchema>[0];

// Business categories
export const businessCategoriesSchema = z.array(z.object({
  id: z.string(),
  name: z.string(),
  type: z.string() // Google Places API type
}));

export type BusinessCategory = z.infer<typeof businessCategoriesSchema>[0];

import { District, BusinessCategory } from "@shared/schema";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { useState, useEffect } from "react";

interface HeroSectionProps {
  districts: District[];
  businessCategories: BusinessCategory[];
  onSearch: () => void;
  selectedDistrict: string;
  selectedBusinessType: string;
  onDistrictChange: (district: string) => void;
  onBusinessTypeChange: (type: string) => void;
}

export default function HeroSection({
  districts,
  businessCategories,
  onSearch,
  selectedDistrict,
  selectedBusinessType,
  onDistrictChange,
  onBusinessTypeChange
}: HeroSectionProps) {
  const [district, setDistrict] = useState(selectedDistrict);
  const [businessType, setBusinessType] = useState(selectedBusinessType);

  // Update local state when props change
  useEffect(() => {
    setDistrict(selectedDistrict);
    setBusinessType(selectedBusinessType);
  }, [selectedDistrict, selectedBusinessType]);

  const handleSearch = () => {
    onDistrictChange(district);
    onBusinessTypeChange(businessType);
    onSearch();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <section className="bg-gradient-to-r from-blue-600 to-blue-500 text-white py-12 md:py-20">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-3xl md:text-5xl font-extrabold mb-4 bg-gradient-to-r from-white to-blue-200 text-transparent bg-clip-text">İstanbul Keşif Rehberi</h1>
        <p className="text-lg md:text-xl mb-8 max-w-3xl mx-auto text-blue-100">
          İstanbul'un tüm ilçelerindeki işletmeleri kolayca keşfedin, filtreleyin ve en iyilerini bulun.
        </p>
        
        <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-6">
          <div className="grid gap-4 md:grid-cols-3">
            <div className="relative">
              <label htmlFor="district" className="block text-gray-700 text-sm font-medium mb-2">
                İlçe Seçin
              </label>
              <Select 
                value={district} 
                onValueChange={setDistrict}
                onOpenChange={() => {}}
              >
                <SelectTrigger 
                  id="district"
                  className="w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary rounded-md shadow-sm bg-white"
                  onKeyDown={handleKeyDown}
                >
                  <SelectValue placeholder="İlçe seçiniz" />
                </SelectTrigger>
                <SelectContent>
                  {districts.map(district => (
                    <SelectItem key={district.id} value={district.id}>
                      {district.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="relative">
              <label htmlFor="business-type" className="block text-gray-700 text-sm font-medium mb-2">
                İşletme Türü
              </label>
              <Select 
                value={businessType} 
                onValueChange={setBusinessType}
                onOpenChange={() => {}}
              >
                <SelectTrigger 
                  id="business-type"
                  className="w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary rounded-md shadow-sm bg-white"
                  onKeyDown={handleKeyDown}
                >
                  <SelectValue placeholder="İşletme türü seçiniz" />
                </SelectTrigger>
                <SelectContent>
                  {businessCategories.map(category => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-end">
              <Button 
                onClick={handleSearch}
                className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-white bg-primary hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition duration-150"
              >
                <Search className="h-4 w-4 mr-2" /> Ara
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

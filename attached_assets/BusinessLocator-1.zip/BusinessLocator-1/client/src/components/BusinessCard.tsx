import { Business } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Star, MapPin, MessageSquare, Clock, Utensils, Coffee, Wine, ShoppingBag, Navigation } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface BusinessCardProps {
  business: Business;
}

export default function BusinessCard({ business }: BusinessCardProps) {
  const getBusinessTypeIcon = (types: string[] = []) => {
    if (types.includes('restaurant')) return <Utensils className="w-4 h-4 mr-1" />;
    if (types.includes('cafe')) return <Coffee className="w-4 h-4 mr-1" />;
    if (types.includes('bar')) return <Wine className="w-4 h-4 mr-1" />;
    if (types.includes('shopping_mall')) return <ShoppingBag className="w-4 h-4 mr-1" />;
    return null;
  };

  const getPriceLevel = (level?: number) => {
    if (level === undefined) return null;
    switch (level) {
      case 0: return <Badge variant="outline">Ücretsiz</Badge>;
      case 1: return <Badge variant="outline">$</Badge>;
      case 2: return <Badge variant="outline">$$</Badge>;
      case 3: return <Badge variant="outline">$$$</Badge>;
      case 4: return <Badge variant="outline">$$$$</Badge>;
      default: return null;
    }
  };

  // Prepare business types
  const businessTypes = business.types?.filter(type => 
    !['point_of_interest', 'establishment'].includes(type)
  ).map(type => {
    // Map API types to user-friendly names
    const typeMap: Record<string, string> = {
      'restaurant': 'Restoran',
      'cafe': 'Kafe',
      'bar': 'Bar',
      'food': 'Yemek',
      'bakery': 'Fırın',
      'shopping_mall': 'Alışveriş Merkezi',
      'store': 'Mağaza',
      'lodging': 'Konaklama',
      'hotel': 'Otel',
      'beauty_salon': 'Güzellik Salonu',
      'spa': 'Spa',
      'night_club': 'Gece Kulübü',
      'liquor_store': 'İçki Dükkanı',
      'meal_delivery': 'Yemek Teslimatı',
      'meal_takeaway': 'Paket Servis'
    };
    
    return typeMap[type] || type.replace(/_/g, ' ');
  });

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-all duration-300 transform hover:scale-[1.01]">
      <div className="flex flex-col sm:flex-row">
        <div className="sm:w-1/3 h-48 sm:h-auto">
          {business.photos?.length ? (
            <img 
              src={`/api/photo/${business.photos[0].photo_reference}`} 
              alt={business.name}
              className="w-full h-full object-cover" 
            />
          ) : (
            <div className="w-full h-full bg-gray-200 flex items-center justify-center">
              <MapPin className="w-12 h-12 text-gray-400" />
            </div>
          )}
        </div>
        
        <div className="sm:w-2/3 p-4">
          <div className="flex justify-between items-start">
            <h3 className="text-xl font-semibold">{business.name}</h3>
            {business.rating !== undefined && (
              <div className="flex items-center bg-green-100 text-green-800 px-2 py-1 rounded text-sm font-medium">
                <Star className="w-4 h-4 mr-1 text-yellow-500" />
                {business.rating.toFixed(1)}
              </div>
            )}
          </div>
          
          <div className="mt-2 text-sm text-gray-600">
            <div className="flex items-center mb-1">
              <MapPin className="w-4 h-4 mr-1 text-gray-500" />
              <span>{business.vicinity || business.formatted_address}</span>
            </div>
            
            {business.user_ratings_total !== undefined && (
              <div className="flex items-center mb-1">
                <MessageSquare className="w-4 h-4 mr-1 text-gray-500" />
                <span>{business.user_ratings_total} değerlendirme</span>
              </div>
            )}
            
            <div className="flex items-center">
              <Clock className="w-4 h-4 mr-1 text-gray-500" />
              <span>
                {business.opening_hours?.open_now
                  ? "Şu anda açık"
                  : business.opening_hours?.open_now === false
                    ? "Kapalı"
                    : "Çalışma saatleri bilinmiyor"}
              </span>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-1 mt-3">
            {businessTypes?.slice(0, 3).map((type, index) => (
              <Badge key={index} variant="secondary" className="bg-gray-100 text-gray-800 hover:bg-gray-200">
                {type}
              </Badge>
            ))}
            {getPriceLevel(business.price_level)}
          </div>
          
          <div className="mt-4 flex justify-between items-center">
            <Button variant="ghost" className="text-primary hover:text-blue-700 font-medium text-sm">
              <span className="flex items-center">
                {getBusinessTypeIcon(business.types)}
                {(business.types?.includes('restaurant') || business.types?.includes('cafe')) 
                  ? 'Rezervasyon Yap' 
                  : 'İncele'}
              </span>
            </Button>
            
            <Button variant="ghost" className="text-blue-600 hover:text-blue-800 font-medium text-sm">
              <span className="flex items-center">
                <Navigation className="w-4 h-4 mr-1" />
                Yol Tarifi
              </span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Star } from "lucide-react";

interface FiltersProps {
  openNow: boolean;
  minRating?: number;
  priceLevel?: number[];
  onOpenNowChange: (openNow: boolean) => void;
  onMinRatingChange: (rating: number | undefined) => void;
  onPriceLevelChange: (prices: number[]) => void;
  onApplyFilters: () => void;
  onResetFilters: () => void;
}

export default function Filters({
  openNow,
  minRating,
  priceLevel = [],
  onOpenNowChange,
  onMinRatingChange,
  onPriceLevelChange,
  onApplyFilters,
  onResetFilters
}: FiltersProps) {
  const [localOpenNow, setLocalOpenNow] = useState(openNow);
  const [localMinRating, setLocalMinRating] = useState<number | undefined>(minRating);
  const [localPriceLevel, setLocalPriceLevel] = useState<number[]>(priceLevel);

  // Update local state when props change
  useEffect(() => {
    setLocalOpenNow(openNow);
    setLocalMinRating(minRating);
    setLocalPriceLevel(priceLevel || []);
  }, [openNow, minRating, priceLevel]);

  // Handle rating changes
  const handleRatingChange = (rating: number, checked: boolean) => {
    if (checked) {
      setLocalMinRating(rating);
    } else if (localMinRating === rating) {
      setLocalMinRating(undefined);
    }
  };

  // Handle price level changes
  const handlePriceLevelChange = (level: number, checked: boolean) => {
    if (checked) {
      setLocalPriceLevel(prev => [...prev, level].filter((v, i, a) => a.indexOf(v) === i));
    } else {
      setLocalPriceLevel(prev => prev.filter(p => p !== level));
    }
  };

  // Apply filters
  const applyFilters = () => {
    onOpenNowChange(localOpenNow);
    onMinRatingChange(localMinRating);
    onPriceLevelChange(localPriceLevel);
    onApplyFilters();
  };

  // Reset filters
  const resetFilters = () => {
    setLocalOpenNow(false);
    setLocalMinRating(undefined);
    setLocalPriceLevel([]);
    onResetFilters();
  };

  return (
    <Card className="p-4">
      <h3 className="font-semibold text-lg mb-3">Filtreler</h3>
      <div className="space-y-4">
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-2">Derecelendirme</h4>
          <div className="flex flex-col space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="rating-5" 
                checked={localMinRating === 5}
                onCheckedChange={(checked) => handleRatingChange(5, !!checked)}
              />
              <Label htmlFor="rating-5" className="flex items-center">
                {[1, 2, 3, 4, 5].map(star => (
                  <Star key={star} className="w-4 h-4 text-yellow-500" fill="currentColor" />
                ))}
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="rating-4" 
                checked={localMinRating === 4}
                onCheckedChange={(checked) => handleRatingChange(4, !!checked)}
              />
              <Label htmlFor="rating-4" className="flex items-center">
                {[1, 2, 3, 4].map(star => (
                  <Star key={star} className="w-4 h-4 text-yellow-500" fill="currentColor" />
                ))}
                <Star className="w-4 h-4 text-gray-300" fill="currentColor" />
                <span className="ml-1 text-sm text-gray-700">ve üzeri</span>
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="rating-3" 
                checked={localMinRating === 3}
                onCheckedChange={(checked) => handleRatingChange(3, !!checked)}
              />
              <Label htmlFor="rating-3" className="flex items-center">
                {[1, 2, 3].map(star => (
                  <Star key={star} className="w-4 h-4 text-yellow-500" fill="currentColor" />
                ))}
                {[4, 5].map(star => (
                  <Star key={star} className="w-4 h-4 text-gray-300" fill="currentColor" />
                ))}
                <span className="ml-1 text-sm text-gray-700">ve üzeri</span>
              </Label>
            </div>
          </div>
        </div>
        
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-2">Şu anda Açık</h4>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="open-now" 
              checked={localOpenNow}
              onCheckedChange={(checked) => setLocalOpenNow(!!checked)}
            />
            <Label htmlFor="open-now" className="text-sm text-gray-700">
              Sadece şu anda açık olanları göster
            </Label>
          </div>
        </div>
        
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-2">Fiyat Aralığı</h4>
          <div className="flex flex-col space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="price-1" 
                checked={localPriceLevel.includes(1)}
                onCheckedChange={(checked) => handlePriceLevelChange(1, !!checked)}
              />
              <Label htmlFor="price-1" className="text-sm text-gray-700">
                $ (Uygun Fiyatlı)
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="price-2" 
                checked={localPriceLevel.includes(2)}
                onCheckedChange={(checked) => handlePriceLevelChange(2, !!checked)}
              />
              <Label htmlFor="price-2" className="text-sm text-gray-700">
                $$ (Orta Fiyatlı)
              </Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="price-3" 
                checked={localPriceLevel.includes(3)}
                onCheckedChange={(checked) => handlePriceLevelChange(3, !!checked)}
              />
              <Label htmlFor="price-3" className="text-sm text-gray-700">
                $$$ (Yüksek Fiyatlı)
              </Label>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-2">
          <Button
            variant="outline"
            onClick={resetFilters}
            className="w-full"
          >
            Sıfırla
          </Button>
          
          <Button
            onClick={applyFilters}
            className="w-full"
          >
            Uygula
          </Button>
        </div>
      </div>
    </Card>
  );
}

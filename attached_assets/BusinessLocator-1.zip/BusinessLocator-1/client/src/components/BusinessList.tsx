import { useState } from "react";
import { Business } from "@shared/schema";
import BusinessCard from "./BusinessCard";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Pagination, PaginationContent, PaginationEllipsis, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { Skeleton } from "@/components/ui/skeleton";

interface BusinessListProps {
  businesses: Business[];
  isLoading: boolean;
  isInitialSearch: boolean;
  totalResults?: number;
  sortBy?: string;
  onSortChange: (sortBy: string) => void;
}

export default function BusinessList({
  businesses,
  isLoading,
  isInitialSearch,
  totalResults = 0,
  sortBy = "relevance",
  onSortChange
}: BusinessListProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;
  
  // Calculate pagination
  const totalPages = Math.ceil(businesses.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = Math.min(startIndex + itemsPerPage, businesses.length);
  const currentBusinesses = businesses.slice(startIndex, endIndex);
  
  // Generate page numbers
  const pageNumbers = [];
  for (let i = 1; i <= totalPages; i++) {
    pageNumbers.push(i);
  }

  if (isInitialSearch) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <h2 className="text-xl font-bold mb-2">İstanbul'da keşfe başlayın</h2>
        <p className="text-gray-600 text-center max-w-md">İlçe ve işletme türü seçerek aramanızı yapın ve İstanbul'un en iyi işletmelerini keşfedin.</p>
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
        <h2 className="text-xl font-bold">
          Sonuçlar 
          {!isLoading && <span className="text-gray-500 text-lg ml-1">({totalResults})</span>}
        </h2>
        <div className="mt-2 sm:mt-0 flex items-center">
          <label htmlFor="sort" className="mr-2 text-sm text-gray-600">Sırala:</label>
          <Select value={sortBy} onValueChange={onSortChange}>
            <SelectTrigger 
              id="sort"
              className="block w-full sm:w-auto pl-3 pr-10 py-1.5 text-sm border-gray-300 focus:outline-none focus:ring-primary focus:border-primary rounded-md shadow-sm bg-white"
            >
              <SelectValue placeholder="Sıralama seçin" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="relevance">İlgililik</SelectItem>
              <SelectItem value="rating">Puan (Yüksek-Düşük)</SelectItem>
              <SelectItem value="reviews">Yorum Sayısı</SelectItem>
              <SelectItem value="distance">Mesafe</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid gap-4">
        {isLoading ? (
          // Loading skeleton
          Array.from({ length: 3 }).map((_, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden p-4">
              <div className="flex flex-col sm:flex-row">
                <div className="sm:w-1/3 h-48 sm:h-auto">
                  <Skeleton className="h-full w-full" />
                </div>
                <div className="sm:w-2/3 p-4">
                  <Skeleton className="h-8 w-3/4 mb-4" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-3/4 mb-4" />
                  <div className="flex flex-wrap gap-1 mt-3">
                    <Skeleton className="h-6 w-20 rounded-full" />
                    <Skeleton className="h-6 w-16 rounded-full" />
                    <Skeleton className="h-6 w-12 rounded-full" />
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : businesses.length === 0 ? (
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <p className="text-lg font-medium mb-2">Sonuç bulunamadı</p>
            <p className="text-gray-600">Lütfen farklı bir ilçe veya işletme türü seçerek tekrar arayın.</p>
          </div>
        ) : (
          currentBusinesses.map((business) => (
            <BusinessCard key={business.place_id} business={business} />
          ))
        )}

        {!isLoading && businesses.length > 0 && (
          <Pagination className="mt-6">
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious 
                  href="#" 
                  onClick={(e) => {
                    e.preventDefault();
                    if (currentPage > 1) setCurrentPage(currentPage - 1);
                  }}
                  className={currentPage <= 1 ? "pointer-events-none opacity-50" : ""}
                />
              </PaginationItem>
              
              {pageNumbers.map(number => (
                <PaginationItem key={number}>
                  <PaginationLink 
                    href="#" 
                    onClick={(e) => {
                      e.preventDefault();
                      setCurrentPage(number);
                    }}
                    isActive={currentPage === number}
                  >
                    {number}
                  </PaginationLink>
                </PaginationItem>
              ))}
              
              {totalPages > 5 && <PaginationEllipsis />}
              
              <PaginationItem>
                <PaginationNext 
                  href="#" 
                  onClick={(e) => {
                    e.preventDefault();
                    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
                  }}
                  className={currentPage >= totalPages ? "pointer-events-none opacity-50" : ""}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        )}
      </div>
    </div>
  );
}

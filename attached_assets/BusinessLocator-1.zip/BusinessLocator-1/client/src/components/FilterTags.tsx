import { SearchParams, District, BusinessCategory } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface FilterTagsProps {
  searchParams: SearchParams;
  districts: District[];
  businessCategories: BusinessCategory[];
  onRemoveFilter: (filterName: string) => void;
  onClearFilters: () => void;
}

export default function FilterTags({
  searchParams,
  districts,
  businessCategories,
  onRemoveFilter,
  onClearFilters
}: FilterTagsProps) {
  // No filters applied
  if (!searchParams.district && !searchParams.businessType && 
      !searchParams.openNow && !searchParams.minRating && 
      (!searchParams.priceLevel || searchParams.priceLevel.length === 0)) {
    return null;
  }

  // Get display names
  const getDistrictName = (id: string) => {
    const district = districts.find(d => d.id === id);
    return district ? district.name : id;
  };

  const getCategoryName = (id: string) => {
    const category = businessCategories.find(c => c.id === id);
    return category ? category.name : id;
  };

  return (
    <div className="mb-6 flex flex-wrap items-center gap-2">
      <span className="text-gray-600 font-medium">Filtreler:</span>
      
      {searchParams.district && (
        <Badge 
          variant="secondary"
          className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800"
        >
          {getDistrictName(searchParams.district)}
          <Button
            variant="ghost"
            size="sm"
            className="ml-1.5 inline-flex text-blue-500 hover:text-blue-600 p-0 h-4"
            onClick={() => onRemoveFilter('district')}
          >
            <X className="h-4 w-4" />
            <span className="sr-only">Remove</span>
          </Button>
        </Badge>
      )}
      
      {searchParams.businessType && (
        <Badge 
          variant="secondary"
          className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800"
        >
          {getCategoryName(searchParams.businessType)}
          <Button
            variant="ghost"
            size="sm"
            className="ml-1.5 inline-flex text-blue-500 hover:text-blue-600 p-0 h-4"
            onClick={() => onRemoveFilter('businessType')}
          >
            <X className="h-4 w-4" />
            <span className="sr-only">Remove</span>
          </Button>
        </Badge>
      )}
      
      {searchParams.openNow && (
        <Badge 
          variant="secondary"
          className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800"
        >
          Şu anda açık
          <Button
            variant="ghost"
            size="sm"
            className="ml-1.5 inline-flex text-blue-500 hover:text-blue-600 p-0 h-4"
            onClick={() => onRemoveFilter('openNow')}
          >
            <X className="h-4 w-4" />
            <span className="sr-only">Remove</span>
          </Button>
        </Badge>
      )}
      
      {searchParams.minRating && (
        <Badge 
          variant="secondary"
          className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800"
        >
          {searchParams.minRating}+ Yıldız
          <Button
            variant="ghost"
            size="sm"
            className="ml-1.5 inline-flex text-blue-500 hover:text-blue-600 p-0 h-4"
            onClick={() => onRemoveFilter('minRating')}
          >
            <X className="h-4 w-4" />
            <span className="sr-only">Remove</span>
          </Button>
        </Badge>
      )}
      
      {searchParams.priceLevel && searchParams.priceLevel.length > 0 && (
        <Badge 
          variant="secondary"
          className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800"
        >
          Fiyat: {searchParams.priceLevel.map(p => '$'.repeat(p)).join(', ')}
          <Button
            variant="ghost"
            size="sm"
            className="ml-1.5 inline-flex text-blue-500 hover:text-blue-600 p-0 h-4"
            onClick={() => onRemoveFilter('priceLevel')}
          >
            <X className="h-4 w-4" />
            <span className="sr-only">Remove</span>
          </Button>
        </Badge>
      )}
      
      <Button
        variant="ghost"
        className="text-primary hover:text-blue-700 text-sm font-medium"
        onClick={onClearFilters}
      >
        Filtreleri Temizle
      </Button>
    </div>
  );
}

import { Link } from "wouter";
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Map 
} from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-8 mt-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Map className="h-6 w-6 text-blue-400" />
              <h3 className="text-lg font-semibold">İstanbul Keşif Rehberi</h3>
            </div>
            <p className="text-gray-400 text-sm">İstanbul'un tüm ilçelerindeki işletmeleri kolayca keşfedin, filtreleyin ve en iyilerini bulun.</p>
          </div>
          
          <div>
            <h4 className="text-md font-semibold mb-3">Popüler Kategoriler</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link href="/" className="hover:text-white">Restoranlar</Link></li>
              <li><Link href="/" className="hover:text-white">Kafeler</Link></li>
              <li><Link href="/" className="hover:text-white">Alışveriş Merkezleri</Link></li>
              <li><Link href="/" className="hover:text-white">Oteller</Link></li>
              <li><Link href="/" className="hover:text-white">Müzeler</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-md font-semibold mb-3">Popüler İlçeler</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link href="/" className="hover:text-white">Kadıköy</Link></li>
              <li><Link href="/" className="hover:text-white">Beşiktaş</Link></li>
              <li><Link href="/" className="hover:text-white">Üsküdar</Link></li>
              <li><Link href="/" className="hover:text-white">Beyoğlu</Link></li>
              <li><Link href="/" className="hover:text-white">Fatih</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-400">© {new Date().getFullYear()} İstanbul Keşif Rehberi. Tüm hakları saklıdır.</p>
        </div>
      </div>
    </footer>
  );
}

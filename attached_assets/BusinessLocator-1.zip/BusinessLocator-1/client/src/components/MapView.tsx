import { useEffect, useRef, useState } from "react";
import { Business } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Star, RefreshCw, Maximize } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface MapFilters {
  openNow?: boolean;
  minRating?: number;
  priceLevel?: number[];
}

interface FilterChangeHandlers {
  setOpenNow: (value: boolean) => void;
  setMinRating: (value: number | undefined) => void;
  setPriceLevel: (value: number[]) => void;
}

interface MapViewProps {
  businesses: Business[];
  center?: { lat: number, lng: number };
  isLoading: boolean;
  filters: MapFilters;
  onFilterChange: FilterChangeHandlers;
}

export default function MapView({
  businesses,
  center = { lat: 41.0082, lng: 28.9784 }, // Istanbul center as default
  isLoading,
  filters,
  onFilterChange
}: MapViewProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const googleMapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const [mapLoaded, setMapLoaded] = useState(false);
  
  // Initialize map
  useEffect(() => {
    if (!window.google?.maps || !mapRef.current) return;
    
    const mapOptions: google.maps.MapOptions = {
      center: center,
      zoom: 13,
      mapTypeControl: false,
      fullscreenControl: false,
      streetViewControl: false,
      zoomControl: true,
      zoomControlOptions: {
        position: google.maps.ControlPosition.RIGHT_TOP
      }
    };
    
    googleMapRef.current = new google.maps.Map(mapRef.current, mapOptions);
    setMapLoaded(true);
  }, [mapRef.current, window.google?.maps]);
  
  // Update map center when district changes
  useEffect(() => {
    if (!googleMapRef.current || !center) return;
    googleMapRef.current.setCenter(center);
    googleMapRef.current.setZoom(14);
  }, [center]);
  
  // Update markers when businesses change
  useEffect(() => {
    if (!googleMapRef.current || !mapLoaded) return;
    
    // Clear old markers
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];
    
    // Add new markers
    businesses.forEach((business, index) => {
      const { lat, lng } = business.geometry.location;
      
      const marker = new google.maps.Marker({
        position: { lat, lng },
        map: googleMapRef.current,
        title: business.name,
        animation: google.maps.Animation.DROP,
        label: {
          text: (index + 1).toString(),
          color: 'white',
          fontWeight: 'bold'
        }
      });
      
      // Create info window
      const infoWindow = new google.maps.InfoWindow({
        content: `
          <div class="p-2">
            <h3 class="font-semibold">${business.name}</h3>
            <p class="text-sm">${business.vicinity || business.formatted_address || ''}</p>
            ${business.rating ? `
              <div class="flex items-center mt-1">
                <span class="text-yellow-500">★</span>
                <span class="ml-1">${business.rating}</span>
              </div>
            ` : ''}
          </div>
        `
      });
      
      // Add click listener to show info window
      marker.addListener('click', () => {
        infoWindow.open(googleMapRef.current, marker);
      });
      
      markersRef.current.push(marker);
    });
    
    // Fit bounds if we have markers
    if (markersRef.current.length > 0) {
      const bounds = new google.maps.LatLngBounds();
      markersRef.current.forEach(marker => {
        bounds.extend(marker.getPosition()!);
      });
      googleMapRef.current.fitBounds(bounds);
      
      // Don't zoom in too much
      const listener = google.maps.event.addListener(googleMapRef.current, 'idle', () => {
        if (googleMapRef.current!.getZoom()! > 16) {
          googleMapRef.current!.setZoom(16);
        }
        google.maps.event.removeListener(listener);
      });
    }
  }, [businesses, mapLoaded]);
  
  const handleRefreshMap = () => {
    if (!googleMapRef.current || !mapLoaded) return;
    
    if (markersRef.current.length > 0) {
      const bounds = new google.maps.LatLngBounds();
      markersRef.current.forEach(marker => {
        bounds.extend(marker.getPosition()!);
      });
      googleMapRef.current.fitBounds(bounds);
    } else if (center) {
      googleMapRef.current.setCenter(center);
      googleMapRef.current.setZoom(14);
    }
  };
  
  const handleFullScreen = () => {
    if (!googleMapRef.current || !mapLoaded) return;
    
    const mapDiv = mapRef.current;
    if (!mapDiv) return;
    
    if (mapDiv.requestFullscreen) {
      mapDiv.requestFullscreen();
    }
  };
  
  return (
    <div className="sticky top-20">
      <Card className="overflow-hidden mb-4">
        <div className="h-[500px] bg-gray-100 relative">
          {isLoading ? (
            <Skeleton className="w-full h-full" />
          ) : (
            <div ref={mapRef} className="w-full h-full"></div>
          )}
        </div>
        <div className="p-3 border-t">
          <div className="flex justify-between items-center">
            <Button 
              variant="ghost" 
              onClick={handleRefreshMap}
              className="text-primary hover:text-blue-700 text-sm font-medium"
            >
              <RefreshCw className="w-4 h-4 mr-1" /> Haritayı Yenile
            </Button>
            <Button 
              variant="ghost" 
              onClick={handleFullScreen}
              className="text-primary hover:text-blue-700 text-sm font-medium"
            >
              <Maximize className="w-4 h-4 mr-1" /> Tam Ekran
            </Button>
          </div>
        </div>
      </Card>
      
      <Card className="p-4">
        <h3 className="font-semibold text-lg mb-3">Filtreler</h3>
        <div className="space-y-4">
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-2">Derecelendirme</h4>
            <div className="flex flex-col space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="rating-5" 
                  checked={filters.minRating === 5}
                  onCheckedChange={(checked) => {
                    onFilterChange.setMinRating(checked ? 5 : undefined);
                  }}
                />
                <Label htmlFor="rating-5" className="flex items-center">
                  {[1, 2, 3, 4, 5].map(star => (
                    <Star key={star} className="w-4 h-4 text-yellow-500" fill="currentColor" />
                  ))}
                </Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="rating-4" 
                  checked={filters.minRating === 4}
                  onCheckedChange={(checked) => {
                    onFilterChange.setMinRating(checked ? 4 : undefined);
                  }}
                />
                <Label htmlFor="rating-4" className="flex items-center">
                  {[1, 2, 3, 4].map(star => (
                    <Star key={star} className="w-4 h-4 text-yellow-500" fill="currentColor" />
                  ))}
                  <Star className="w-4 h-4 text-gray-300" fill="currentColor" />
                  <span className="ml-1 text-sm text-gray-700">ve üzeri</span>
                </Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="rating-3" 
                  checked={filters.minRating === 3}
                  onCheckedChange={(checked) => {
                    onFilterChange.setMinRating(checked ? 3 : undefined);
                  }}
                />
                <Label htmlFor="rating-3" className="flex items-center">
                  {[1, 2, 3].map(star => (
                    <Star key={star} className="w-4 h-4 text-yellow-500" fill="currentColor" />
                  ))}
                  {[4, 5].map(star => (
                    <Star key={star} className="w-4 h-4 text-gray-300" fill="currentColor" />
                  ))}
                  <span className="ml-1 text-sm text-gray-700">ve üzeri</span>
                </Label>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-2">Şu anda Açık</h4>
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="open-now" 
                checked={filters.openNow}
                onCheckedChange={(checked) => {
                  onFilterChange.setOpenNow(!!checked);
                }}
              />
              <Label htmlFor="open-now" className="text-sm text-gray-700">
                Sadece şu anda açık olanları göster
              </Label>
            </div>
          </div>
          
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-2">Fiyat Aralığı</h4>
            <div className="flex flex-col space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="price-1" 
                  checked={filters.priceLevel?.includes(1)}
                  onCheckedChange={(checked) => {
                    const currentPrices = filters.priceLevel || [];
                    if (checked) {
                      onFilterChange.setPriceLevel([...currentPrices, 1].filter((v, i, a) => a.indexOf(v) === i));
                    } else {
                      onFilterChange.setPriceLevel(currentPrices.filter(p => p !== 1));
                    }
                  }}
                />
                <Label htmlFor="price-1" className="text-sm text-gray-700">
                  $ (Uygun Fiyatlı)
                </Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="price-2" 
                  checked={filters.priceLevel?.includes(2)}
                  onCheckedChange={(checked) => {
                    const currentPrices = filters.priceLevel || [];
                    if (checked) {
                      onFilterChange.setPriceLevel([...currentPrices, 2].filter((v, i, a) => a.indexOf(v) === i));
                    } else {
                      onFilterChange.setPriceLevel(currentPrices.filter(p => p !== 2));
                    }
                  }}
                />
                <Label htmlFor="price-2" className="text-sm text-gray-700">
                  $$ (Orta Fiyatlı)
                </Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="price-3" 
                  checked={filters.priceLevel?.includes(3)}
                  onCheckedChange={(checked) => {
                    const currentPrices = filters.priceLevel || [];
                    if (checked) {
                      onFilterChange.setPriceLevel([...currentPrices, 3].filter((v, i, a) => a.indexOf(v) === i));
                    } else {
                      onFilterChange.setPriceLevel(currentPrices.filter(p => p !== 3));
                    }
                  }}
                />
                <Label htmlFor="price-3" className="text-sm text-gray-700">
                  $$$ (Yüksek Fiyatlı)
                </Label>
              </div>
            </div>
          </div>
          
          <Button
            onClick={() => {
              onFilterChange.setOpenNow(false);
              onFilterChange.setMinRating(undefined);
              onFilterChange.setPriceLevel([]);
            }}
            className="w-full mt-4"
          >
            Filtreleri Sıfırla
          </Button>
        </div>
      </Card>
    </div>
  );
}

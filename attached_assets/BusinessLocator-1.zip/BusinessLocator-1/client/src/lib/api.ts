import { SearchParams, SearchResult, Business } from "@shared/schema";
import { apiRequest } from "./queryClient";

/**
 * Fetches districts from the API
 */
export async function getDistricts() {
  const res = await apiRequest("GET", "/api/districts");
  return await res.json();
}

/**
 * Fetches business categories from the API
 */
export async function getBusinessCategories() {
  const res = await apiRequest("GET", "/api/business-categories");
  return await res.json();
}

/**
 * Searches for businesses with the given parameters
 */
export async function searchBusinesses(params: SearchParams): Promise<SearchResult> {
  // Build query string
  const queryParams = new URLSearchParams();
  
  if (params.district) {
    queryParams.append("district", params.district);
  }
  
  if (params.businessType) {
    queryParams.append("businessType", params.businessType);
  }
  
  if (params.radius) {
    queryParams.append("radius", params.radius.toString());
  }
  
  if (params.openNow) {
    queryParams.append("openNow", "true");
  }
  
  if (params.minRating) {
    queryParams.append("minRating", params.minRating.toString());
  }
  
  if (params.priceLevel && params.priceLevel.length > 0) {
    queryParams.append("priceLevel", params.priceLevel.join(","));
  }
  
  if (params.pageToken) {
    queryParams.append("pageToken", params.pageToken);
  }
  
  if (params.sortBy) {
    queryParams.append("sortBy", params.sortBy);
  }
  
  const res = await apiRequest("GET", `/api/search?${queryParams.toString()}`);
  return await res.json();
}

/**
 * Fetches details for a specific business
 */
export async function getBusinessDetails(placeId: string): Promise<Business> {
  const res = await apiRequest("GET", `/api/business/${placeId}`);
  return await res.json();
}

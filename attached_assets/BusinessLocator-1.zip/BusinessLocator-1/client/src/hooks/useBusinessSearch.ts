import { useState, useEffect, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { SearchParams, Business, District, BusinessCategory } from "@shared/schema";
import { getDistricts, getBusinessCategories, searchBusinesses } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

export function useBusinessSearch() {
  const { toast } = useToast();
  const [searchParams, setSearchParams] = useState<SearchParams>({
    district: "",
    businessType: "",
    radius: 5000,
    openNow: false,
    minRating: undefined,
    priceLevel: [],
    sortBy: "relevance"
  });
  
  const [results, setResults] = useState<Business[]>([]);
  const [totalResults, setTotalResults] = useState<number>(0);
  const [nextPageToken, setNextPageToken] = useState<string | undefined>(undefined);
  const [isInitialSearch, setIsInitialSearch] = useState(true);
  
  // Fetch districts
  const districtsQuery = useQuery({
    queryKey: ['/api/districts'],
    retry: 3
  });
  
  // Fetch business categories
  const categoriesQuery = useQuery({
    queryKey: ['/api/business-categories'],
    retry: 3
  });
  
  // Search businesses query
  const searchQuery = useQuery({
    queryKey: ['/api/search', searchParams],
    enabled: false, // Don't automatically run this query
    retry: 1
  });
  
  // Extract data from queries
  const districts: District[] = districtsQuery.data || [];
  const businessCategories: BusinessCategory[] = categoriesQuery.data || [];
  
  // Handle search
  const search = useCallback(async () => {
    if (!searchParams.district && !searchParams.businessType) {
      toast({
        title: "Lütfen en az bir ilçe veya işletme türü seçin",
        variant: "destructive"
      });
      return;
    }
    
    try {
      setIsInitialSearch(false);
      
      const result = await searchBusinesses(searchParams);
      
      setResults(result.results);
      setTotalResults(result.total || result.results.length);
      setNextPageToken(result.next_page_token);
    } catch (error) {
      console.error("Search error:", error);
      toast({
        title: "Arama sırasında bir hata oluştu",
        description: "Lütfen daha sonra tekrar deneyin",
        variant: "destructive"
      });
    }
  }, [searchParams, toast]);
  
  // Update filters
  const setDistrict = useCallback((district: string) => {
    setSearchParams(prev => ({ ...prev, district }));
  }, []);
  
  const setBusinessType = useCallback((businessType: string) => {
    setSearchParams(prev => ({ ...prev, businessType }));
  }, []);
  
  const setOpenNow = useCallback((openNow: boolean) => {
    setSearchParams(prev => ({ ...prev, openNow }));
  }, []);
  
  const setMinRating = useCallback((minRating: number | undefined) => {
    setSearchParams(prev => ({ ...prev, minRating }));
  }, []);
  
  const setPriceLevel = useCallback((priceLevel: number[]) => {
    setSearchParams(prev => ({ ...prev, priceLevel }));
  }, []);
  
  const setSortBy = useCallback((sortBy: string) => {
    setSearchParams(prev => ({ ...prev, sortBy }));
    // Re-search immediately when sort changes
    setTimeout(() => search(), 0);
  }, [search]);
  
  // Remove specific filter
  const removeFilter = useCallback((filterName: string) => {
    setSearchParams(prev => {
      const updated = { ...prev };
      
      switch (filterName) {
        case 'district':
          updated.district = "";
          break;
        case 'businessType':
          updated.businessType = "";
          break;
        case 'openNow':
          updated.openNow = false;
          break;
        case 'minRating':
          updated.minRating = undefined;
          break;
        case 'priceLevel':
          updated.priceLevel = [];
          break;
      }
      
      return updated;
    });
  }, []);
  
  // Clear all filters
  const clearFilters = useCallback(() => {
    setSearchParams({
      district: "",
      businessType: "",
      radius: 5000,
      openNow: false,
      minRating: undefined,
      priceLevel: [],
      sortBy: "relevance"
    });
    setIsInitialSearch(true);
    setResults([]);
    setTotalResults(0);
    setNextPageToken(undefined);
  }, []);
  
  // Run search when filters change (except for initial load)
  useEffect(() => {
    if (!isInitialSearch && (searchParams.district || searchParams.businessType)) {
      const timer = setTimeout(() => {
        search();
      }, 300);
      
      return () => clearTimeout(timer);
    }
  }, [
    searchParams.district, 
    searchParams.businessType, 
    searchParams.openNow, 
    searchParams.minRating, 
    searchParams.priceLevel, 
    isInitialSearch, 
    search
  ]);
  
  return {
    searchParams,
    results,
    totalResults,
    nextPageToken,
    isLoading: searchQuery.isLoading || searchQuery.isFetching,
    isInitialSearch,
    setDistrict,
    setBusinessType,
    setOpenNow,
    setMinRating,
    setPriceLevel,
    setSortBy,
    search,
    removeFilter,
    clearFilters,
    districts,
    businessCategories
  };
}

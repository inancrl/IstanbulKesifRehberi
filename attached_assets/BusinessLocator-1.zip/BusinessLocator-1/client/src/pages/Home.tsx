import { useEffect } from "react";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import BusinessList from "@/components/BusinessList";
import MapView from "@/components/MapView";
import FilterTags from "@/components/FilterTags";
import Footer from "@/components/Footer";
import { useBusinessSearch } from "@/hooks/useBusinessSearch";

export default function Home() {
  const { 
    searchParams,
    results,
    isLoading,
    isInitialSearch,
    setDistrict,
    setBusinessType,
    setOpenNow,
    setPriceLevel,
    setMinRating,
    setSortBy,
    clearFilters,
    search,
    removeFilter,
    districts,
    businessCategories,
    totalResults
  } = useBusinessSearch();

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <HeroSection 
        districts={districts}
        businessCategories={businessCategories}
        onSearch={search}
        selectedDistrict={searchParams.district}
        selectedBusinessType={searchParams.businessType}
        onDistrictChange={setDistrict}
        onBusinessTypeChange={setBusinessType}
      />
      
      <main className="container mx-auto px-4 py-8 flex-grow">
        {(searchParams.district || searchParams.businessType) && (
          <FilterTags 
            searchParams={searchParams} 
            districts={districts}
            businessCategories={businessCategories}
            onRemoveFilter={removeFilter}
            onClearFilters={clearFilters}
          />
        )}
        
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="lg:w-2/3 order-2 lg:order-1">
            <BusinessList 
              businesses={results}
              isLoading={isLoading}
              isInitialSearch={isInitialSearch}
              totalResults={totalResults}
              sortBy={searchParams.sortBy}
              onSortChange={setSortBy}
            />
          </div>
          
          <div className="lg:w-1/3 order-1 lg:order-2">
            <MapView 
              businesses={results}
              center={districts.find(d => d.id === searchParams.district)?.location}
              isLoading={isLoading}
              filters={{
                openNow: searchParams.openNow,
                minRating: searchParams.minRating,
                priceLevel: searchParams.priceLevel
              }}
              onFilterChange={{
                setOpenNow,
                setMinRating,
                setPriceLevel
              }}
            />
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

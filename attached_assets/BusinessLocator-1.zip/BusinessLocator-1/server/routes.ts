import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import axios from "axios";
import { searchParamsSchema, searchResultSchema, businessSchema } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Google Maps API key from environment variables
  const apiKey = process.env.GOOGLE_API_KEY || "";
  
  if (!apiKey) {
    console.warn("GOOGLE_API_KEY environment variable is not set. Google API requests will fail.");
  } else {
    console.log("GOOGLE_API_KEY is set and ready to use");
  }

  // Get all available districts
  app.get("/api/districts", async (req: Request, res: Response) => {
    try {
      const districts = await storage.getDistricts();
      res.json(districts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch districts" });
    }
  });

  // Get all business categories
  app.get("/api/business-categories", async (req: Request, res: Response) => {
    try {
      const categories = await storage.getBusinessCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch business categories" });
    }
  });

  // Search businesses
  app.get("/api/search", async (req: Request, res: Response) => {
    try {
      const district = req.query.district as string;
      const businessType = req.query.businessType as string;
      const pageToken = req.query.pageToken as string | undefined;
      const radius = req.query.radius ? parseInt(req.query.radius as string) : 5000;
      const openNow = req.query.openNow === "true";
      const minRating = req.query.minRating ? parseFloat(req.query.minRating as string) : undefined;
      const priceLevel = req.query.priceLevel ? (req.query.priceLevel as string).split(",").map(Number) : undefined;
      const sortBy = req.query.sortBy as string | undefined;

      // Validate parameters
      const validatedParams = searchParamsSchema.parse({
        district,
        businessType,
        radius,
        openNow,
        minRating,
        priceLevel,
        pageToken,
        sortBy
      });

      // Get district coordinates
      const districts = await storage.getDistricts();
      const selectedDistrict = districts.find(d => d.id === district);
      
      if (!selectedDistrict) {
        return res.status(400).json({ message: "Invalid district" });
      }

      // Get business type
      const businessCategories = await storage.getBusinessCategories();
      const selectedCategory = businessCategories.find(c => c.id === businessType);
      
      if (!selectedCategory) {
        return res.status(400).json({ message: "Invalid business type" });
      }

      // Call Google Places API to search for places
      let url = `https://maps.googleapis.com/maps/api/place/nearbysearch/json?`;
      url += `location=${selectedDistrict.location.lat},${selectedDistrict.location.lng}`;
      url += `&radius=${radius}`;
      url += `&type=${selectedCategory.type}`;
      url += `&key=${apiKey}`;
      url += `&maxresults=50`;
      
      if (openNow) {
        url += `&opennow=true`;
      }
      
      if (pageToken) {
        url += `&pagetoken=${pageToken}`;
      }

      const response = await axios.get(url);
      let results = response.data.results;

      // Apply filters
      if (minRating !== undefined) {
        results = results.filter((place: any) => place.rating >= minRating);
      }

      if (priceLevel && priceLevel.length > 0) {
        results = results.filter((place: any) => 
          place.price_level !== undefined && priceLevel.includes(place.price_level)
        );
      }

      // Apply sorting
      if (sortBy) {
        switch (sortBy) {
          case 'rating':
            results.sort((a: any, b: any) => (b.rating || 0) - (a.rating || 0));
            break;
          case 'reviews':
            results.sort((a: any, b: any) => (b.user_ratings_total || 0) - (a.user_ratings_total || 0));
            break;
          // distance is already sorted by the API
          // relevance is the default sorting from the API
        }
      }

      // Format response
      const formattedResponse = {
        results,
        next_page_token: response.data.next_page_token,
        total: results.length
      };

      // Validate with our schema
      const validatedResults = searchResultSchema.parse(formattedResponse);
      
      res.json(validatedResults);
    } catch (error: any) {
      console.error('Error searching businesses:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid search parameters", 
          error: fromZodError(error).message 
        });
      }
      
      res.status(500).json({ message: "Failed to search businesses" });
    }
  });

  // Get business details
  app.get("/api/business/:placeId", async (req: Request, res: Response) => {
    try {
      const { placeId } = req.params;
      
      if (!placeId) {
        return res.status(400).json({ message: "Place ID is required" });
      }

      // Call Google Places API to get place details
      const url = `https://maps.googleapis.com/maps/api/place/details/json?placeid=${placeId}&key=${apiKey}`;
      const response = await axios.get(url);
      
      if (response.data.status !== "OK" || !response.data.result) {
        return res.status(404).json({ message: "Business not found" });
      }

      // Format and validate the response
      const place = response.data.result;
      const business = businessSchema.parse(place);
      
      res.json(business);
    } catch (error: any) {
      console.error('Error fetching business details:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid place data", 
          error: fromZodError(error).message 
        });
      }
      
      res.status(500).json({ message: "Failed to fetch business details" });
    }
  });

  // Get place photo
  app.get("/api/photo/:reference", async (req: Request, res: Response) => {
    try {
      const { reference } = req.params;
      const maxwidth = req.query.maxwidth || 400;
      
      if (!reference) {
        return res.status(400).json({ message: "Photo reference is required" });
      }

      // Build Google Places Photo URL
      const url = `https://maps.googleapis.com/maps/api/place/photo?photoreference=${reference}&maxwidth=${maxwidth}&key=${apiKey}`;
      
      // Proxy the photo request
      const response = await axios.get(url, { responseType: 'stream' });
      
      // Set headers
      if (response.headers['content-type']) {
        res.setHeader('Content-Type', response.headers['content-type']);
      }
      
      // Pipe the image data to our response
      response.data.pipe(res);
    } catch (error: any) {
      console.error('Error fetching photo:', error);
      res.status(500).json({ message: "Failed to fetch photo" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

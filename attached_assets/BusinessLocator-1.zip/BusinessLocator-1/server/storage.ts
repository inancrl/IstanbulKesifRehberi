import { Business, SearchParams, SearchResult, District, BusinessCategory } from "@shared/schema";
import axios from "axios";

export interface IStorage {
  searchBusinesses(params: SearchParams): Promise<SearchResult>;
  getDistricts(): Promise<District[]>;
  getBusinessCategories(): Promise<BusinessCategory[]>;
  getBusinessDetails(placeId: string): Promise<Business | null>;
}

export class MemStorage implements IStorage {
  private districts: District[] = [
    { id: "kadikoy", name: "Kadıköy", location: { lat: 40.9907, lng: 29.0368 } },
    { id: "besiktas", name: "Beşiktaş", location: { lat: 41.0436, lng: 29.0094 } },
    { id: "sisli", name: "Şişli", location: { lat: 41.0601, lng: 28.9879 } },
    { id: "beyoglu", name: "Beyoğlu", location: { lat: 41.0307, lng: 28.9774 } },
    { id: "uskudar", name: "Üsküdar", location: { lat: 41.0237, lng: 29.0148 } },
    { id: "fatih", name: "Fatih", location: { lat: 41.0186, lng: 28.9488 } },
    { id: "atasehir", name: "Ataşehir", location: { lat: 40.9830, lng: 29.1289 } },
    { id: "maltepe", name: "Maltepe", location: { lat: 40.9546, lng: 29.1538 } },
    { id: "bakirkoy", name: "Bakırköy", location: { lat: 40.9813, lng: 28.8772 } },
    { id: "sariyer", name: "Sarıyer", location: { lat: 41.1623, lng: 29.0571 } },
    { id: "adalar", name: "Adalar", location: { lat: 40.8765, lng: 29.0867 } },
    { id: "arnavutkoy", name: "Arnavutköy", location: { lat: 41.1842, lng: 28.7403 } },
    { id: "avcilar", name: "Avcılar", location: { lat: 40.9798, lng: 28.7216 } },
    { id: "bagcilar", name: "Bağcılar", location: { lat: 41.0378, lng: 28.8549 } },
    { id: "bahcelievler", name: "Bahçelievler", location: { lat: 40.9971, lng: 28.8651 } },
    { id: "bahcesehir", name: "Bahçeşehir", location: { lat: 41.0672, lng: 28.6852 } },
    { id: "basaksehir", name: "Başakşehir", location: { lat: 41.0936, lng: 28.8011 } },
    { id: "bayrampasa", name: "Bayrampaşa", location: { lat: 41.0320, lng: 28.9131 } },
    { id: "beykoz", name: "Beykoz", location: { lat: 41.1277, lng: 29.0976 } },
    { id: "beylikduzu", name: "Beylikdüzü", location: { lat: 40.9830, lng: 28.6428 } },
    { id: "buyukcekmece", name: "Büyükçekmece", location: { lat: 41.0202, lng: 28.5956 } },
    { id: "catalca", name: "Çatalca", location: { lat: 41.1430, lng: 28.4615 } },
    { id: "cekmekoy", name: "Çekmeköy", location: { lat: 41.0287, lng: 29.1869 } },
    { id: "esenyurt", name: "Esenyurt", location: { lat: 41.0295, lng: 28.6736 } },
    { id: "eyupsultan", name: "Eyüpsultan", location: { lat: 41.0551, lng: 28.9347 } },
    { id: "gaziosmanpasa", name: "Gaziosmanpaşa", location: { lat: 41.0494, lng: 28.9175 } },
    { id: "gungoren", name: "Güngören", location: { lat: 41.0117, lng: 28.8865 } },
    { id: "kartal", name: "Kartal", location: { lat: 40.8862, lng: 29.1869 } },
    { id: "kucukcekmece", name: "Küçükçekmece", location: { lat: 41.0038, lng: 28.7675 } },
    { id: "pendik", name: "Pendik", location: { lat: 40.8750, lng: 29.2477 } },
    { id: "sancaktepe", name: "Sancaktepe", location: { lat: 40.9980, lng: 29.2353 } },
    { id: "silivri", name: "Silivri", location: { lat: 41.0730, lng: 28.2446 } },
    { id: "sultanbeyli", name: "Sultanbeyli", location: { lat: 40.9656, lng: 29.2714 } },
    { id: "sultangazi", name: "Sultangazi", location: { lat: 41.1063, lng: 28.8672 } },
    { id: "tuzla", name: "Tuzla", location: { lat: 40.8156, lng: 29.3006 } },
    { id: "zeytinburnu", name: "Zeytinburnu", location: { lat: 40.9941, lng: 28.9083 } },
    { id: "sile", name: "Şile", location: { lat: 41.1755, lng: 29.6158 } },
    { id: "esenler", name: "Esenler", location: { lat: 41.0437, lng: 28.8762 } },
    { id: "umraniye", name: "Ümraniye", location: { lat: 41.0158, lng: 29.0963 } }
  ];

  private businessCategories: BusinessCategory[] = [
    { id: "restaurant", name: "Restoranlar", type: "restaurant" },
    { id: "cafe", name: "Kafeler", type: "cafe" },
    { id: "bakery", name: "Fırınlar", type: "bakery" },
    { id: "bar", name: "Barlar", type: "bar" },
    { id: "night_club", name: "Gece Kulüpleri", type: "night_club" },
    { id: "shopping", name: "Alışveriş Merkezleri", type: "shopping_mall" },
    { id: "supermarket", name: "Süpermarketler", type: "supermarket" },
    { id: "clothing_store", name: "Giyim Mağazaları", type: "clothing_store" },
    { id: "hotel", name: "Oteller", type: "lodging" },
    { id: "entertainment", name: "Eğlence Yerleri", type: "amusement_park" },
    { id: "movie_theater", name: "Sinemalar", type: "movie_theater" },
    { id: "park", name: "Parklar", type: "park" },
    { id: "museum", name: "Müzeler", type: "museum" },
    { id: "health", name: "Sağlık Merkezleri", type: "hospital" },
    { id: "pharmacy", name: "Eczaneler", type: "pharmacy" },
    { id: "gym", name: "Spor Salonları", type: "gym" },
    { id: "beauty", name: "Güzellik & Spa", type: "beauty_salon" },
    { id: "hair_care", name: "Kuaförler", type: "hair_care" },
    { id: "bank", name: "Bankalar", type: "bank" },
    { id: "atm", name: "ATM'ler", type: "atm" },
    { id: "gas_station", name: "Benzin İstasyonları", type: "gas_station" },
    { id: "car_dealer", name: "Araba Galerileri", type: "car_dealer" },
    { id: "car_repair", name: "Araba Tamircileri", type: "car_repair" },
    { id: "transit_station", name: "Toplu Taşıma İstasyonları", type: "transit_station" },
    { id: "other", name: "Diğer", type: "point_of_interest" }
  ];

  private cachedResults: Map<string, { timestamp: number, result: SearchResult }> = new Map();
  private cachedBusinessDetails: Map<string, { timestamp: number, business: Business }> = new Map();

  async searchBusinesses(params: SearchParams): Promise<SearchResult> {
    // If we have a Google Maps API key, we would use it to make actual API calls
    // For now, we'll create a proxy function that would call the real API
    // but will be implemented in the routes.ts file

    const cacheKey = JSON.stringify(params);
    const cachedData = this.cachedResults.get(cacheKey);
    
    // Check if we have cached data that's less than 1 hour old
    if (cachedData && (Date.now() - cachedData.timestamp < 3600000)) {
      return cachedData.result;
    }

    // Call to real API will be implemented in routes.ts
    // This would just be a placeholder and would never be called directly
    return { results: [], total: 0 };
  }

  async getDistricts(): Promise<District[]> {
    return this.districts;
  }

  async getBusinessCategories(): Promise<BusinessCategory[]> {
    return this.businessCategories;
  }

  async getBusinessDetails(placeId: string): Promise<Business | null> {
    const cachedData = this.cachedBusinessDetails.get(placeId);
    
    // Check if we have cached data that's less than 1 hour old
    if (cachedData && (Date.now() - cachedData.timestamp < 3600000)) {
      return cachedData.business;
    }

    // Call to real API will be implemented in routes.ts
    // This would just be a placeholder and would never be called directly
    return null;
  }
}

export const storage = new MemStorage();
